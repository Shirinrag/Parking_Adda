<link rel="stylesheet" href="<?= base_url()?>assets/plugins/datatables/dataTables.bootstrap4.css">


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Booking List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Booking Management</a></li>
              <li class="breadcrumb-item active">Booking List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">All Data</h3>
            </div>
            <!-- /.card-header -->
           <div class="card">

      <div class="card-body table-responsive">
        <table id="na_datatable" class="table table-bordered table-striped" width="110%">
          <thead>
            <tr>
              <th>#Id</th>
              <th>Booking Id</th>
              <th style="width:1%">Booking Type</th>
              <th>Cost</th>
              <th style="width:5%">Username</th>
              <th style="width:9  5%">Place Info</th>
              <th>From Date</th>
              <th>To Date</th>  
              <th style="width:15%">Slot Info</th>
              <th>Booking Status</th>
              <th>Paid Status</th>

            </tr>
          </thead>
        </table>
      </div>
    </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

         
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- DataTables -->
<script src="<?= base_url()?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url()?>assets/plugins/datatables/dataTables.bootstrap4.js"></script>

<script>
  //---------------------------------------------------
  var table = $('#na_datatable').DataTable( {
    "processing": true,
    "serverSide": false,
    "ajax": "<?=base_url('admin/Booking/datatable_json')?>",
    "order": [[1,'desc']],
    "columnDefs": [
    { "targets": 0, "name": "id", 'searchable':true, 'orderable':true},
    { "targets": 1, "name": "unique_booking_id", 'searchable':true, 'orderable':true},
    { "targets": 2, "name": "booking_type", 'searchable':true, 'orderable':true},
    { "targets": 3, "name": "cost", 'searchable':true, 'orderable':true},
    { "targets": 4, "name": "firstname", 'searchable':true, 'orderable':true},
    { "targets": 5, "name": "placename", 'searchable':true, 'orderable':true},
    { "targets": 6, "name": "booking_from_date", 'searchable':true, 'orderable':true},
    { "targets": 7, "name": "booking_to_date", 'searchable':true, 'orderable':true},
    { "targets": 8, "name": "slot_name", 'searchable':true, 'orderable':true},
    { "targets": 9, "name": "booking_status", 'searchable':true, 'orderable':true},
    { "targets": 10, "name": "paid_status", 'searchable':true, 'orderable':true},
    
    ]
  });
</script>
</body>
</html>
